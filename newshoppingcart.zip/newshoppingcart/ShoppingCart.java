
/**
 * @author Bo Nappie
 * @version Implementing a Shopping Cart
 */
//import java.util.Arrays;

/** resizable array based implementation including  BagInterface */
public class ShoppingCart
{
   private BagInterface<Item> shoppingCart;
   
   
   
   
   //constructor
   public ShoppingCart()
   {
       shoppingCart= new ResizableArrayBag<>();
    }
    
    public ShoppingCart(BagInterface<Item> bag)
    {
        shoppingCart = bag;
    }
    
    //Adds a new entry to the cart
    // @param item
    // @return TRUE if add was successful, FALSE otherwise
    public boolean add(Item item)
    {
        return shoppingCart.add(item);
        
    }
    
    //Adds multiple of an item to cart
    //@param item, q - the entry to add, and quantity 
    //@return true if all adds were successful 
    public boolean addMultiple(Item item, int q)
    { 
        boolean check = false;
        
        for(int i=0;i<q;i++){
            add(item);
        }
        check = true;
        return check;
    }
    
    //removes specific item from the bag
    //@param which item to remove
    //@return TRUE if item was removed
    public boolean removeSpecific(Item item)
    {
        return shoppingCart.remove(item);
    }
    

    //removes unspecified item
    //@return the item that was removed
    public Item remove()
    {
        Item itemRemoved =  shoppingCart.remove();
        return itemRemoved; 
    }

    //calculates the total price of all items in the cart
    //@returns an int value of the total price
    public int checkout()
    {
        int totalPrice = 0;
        
        while(!shoppingCart.isEmpty())
        {
            Item itemRemoved = shoppingCart.remove();
            totalPrice= totalPrice + itemRemoved.getPrice();
            System.out.println(itemRemoved.toString());
        }
        System.out.println("\nTotal: $" + totalPrice/100 + "." + totalPrice% 100 + "\n");
        
        return totalPrice;
        
    }
    
    //determines if budget is enough for all items
    //@param the budget
    //@return TRUE if the budget is larger/= to sum, FALSE if sum exceeds budget
    public boolean checkBudget(int budget)
    {
        boolean check = false;
        
        Object[] items = shoppingCart.toArray();
        int total = 0;
        for(int i = 0; i < items.length; i++)
        {
            Item item = (Item) items[i];
            total += item.getPrice();
            System.out.println(total);
        }
        while(budget < total)
        {
            Item itemRemoved = shoppingCart.remove();
            total -= itemRemoved.getPrice();
            //break;
        }
        /*
        receiptB += "$" + totalPrice/100 + "." + totalPrice% 100;

        System.out.println("The budget is: $"+ budget + "\n Your total is now: " + receiptB + "\n");
        System.out.println("\n" + "Your budget is sufficient: ");*/
        check = true;
        return check;
        
        }
    }
    
