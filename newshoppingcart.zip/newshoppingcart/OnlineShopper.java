
//** * OnlineShopper.java - driver to test out shopping cart implementation of a Bag
public class OnlineShopper
{
    public static void main(String[] args)
    {
        //Create some Items to add
        Item[] items = {new Item("Pants", 2050),
                        new Item("Sweatshirt", 1587),
                        new Item("Sneakers", 4499),
                        new Item("Boots", 1299),
                        new Item("Sweater", 1588),
                        new Item("Hat", 1699)};
        
        //Create a shopping cart using Resizable array Bag implementation
        ShoppingCart shoppingCart = new ShoppingCart();
        
        
        /*
         * BagInterface arrayBag = ArrayBag<Item>();
         * ShoppingCart shoppingCart2 = new ShoppingCart(arrayBag);
         * 
         */
        
        //Add items to our bag
        for (int i = 0; i < items.length; i++)
        {
            Item nextItem = items[i];
            shoppingCart.add(nextItem);
        }
        
        
        //Add multiple quantities of an item to bag
        System.out.println("Multiple of the same item have been added: " + shoppingCart.addMultiple(items[1], 4));
         
        
        //Remove a specific item
        System.out.println("The specified item was successfully removed: ");
        System.out.println(shoppingCart.removeSpecific(items[4]) +"\n");
        
        //Remove an unspecified item
        shoppingCart.remove();
        System.out.println("The unspecified item was successfully removed: ");
        System.out.println(shoppingCart.remove() +"\n");
         
       //check budget
        System.out.println(shoppingCart.checkBudget(120)); //
        
        //Simulate check out (remove/isEmpty)
           shoppingCart.checkout();
        
        //array bag implementation
        BagInterface arrayBag = new ArrayBag<Item>();
        ShoppingCart shoppingCart2 = new ShoppingCart(arrayBag);
        
        
        Item[] items2 = {new Item("Pants", 2050),
                        new Item("Sweatshirt", 1587),
                        new Item("Sneakers", 4499),
                        new Item("Boots", 1299),
                        new Item("Sweater", 1588),
                        new Item("Hat", 1699),
                        new Item("Jacket", 3500),
                        new Item("Rain boots", 4200)};

        //Add items to our bag
        for (int i = 0; i < items2.length; i++)
        {
            Item nextItem = items2[i];
            shoppingCart2.add(nextItem);
        }
        
        System.out.println("Array bag implementation below: \n");
        
        //Add multiple quantities of an item to bag
        System.out.println("Multiple of the same item have been added: " + shoppingCart2.addMultiple(items2[3], 3));
         
        
        //Remove a specific item
        System.out.println("The specified item was successfully removed: ");
        System.out.println(shoppingCart2.removeSpecific(items2[5]) +"\n");
        
        //Remove an unspecified item
        shoppingCart2.remove();
        System.out.println("The unspecified item was successfully removed: ");
        System.out.println(shoppingCart2.remove() +"\n");
         
       //check budget
        System.out.println(shoppingCart2.checkBudget(180)); //
        
        //Simulate check out (remove/isEmpty)
        shoppingCart2.checkout();
        
        //linked bag implementation
         BagInterface LinkedBag = new LinkedBag<Item>();
        ShoppingCart shoppingCart3 = new ShoppingCart(LinkedBag);
        
        
        Item[] items3 = {new Item("Pants", 2050),
                        new Item("Sweatshirt", 1587),
                        new Item("Sneakers", 4499),
                        new Item("Boots", 1299),
                        new Item("Sweater", 1588),
                        new Item("Hat", 1699),
                        new Item("Jacket", 3500),
                        new Item("Rain boots", 4200),
                        new Item("Gloves", 2100),
                        new Item("Scarf", 3277)};

        //Add items to our bag
        for (int i = 0; i < items3.length; i++)
        {
            Item nextItem = items3[i];
            shoppingCart3.add(nextItem);
        }
        
        System.out.println("Linked bag implementation below: \n");
        
        //Add multiple quantities of an item to bag
        System.out.println("Multiple of the same item have been added: " + shoppingCart3.addMultiple(items3[4], 6));
         
        
        //Remove a specific item
        System.out.println("The specified item was successfully removed: ");
        System.out.println(shoppingCart3.removeSpecific(items3[5]) +"\n");
        
        //Remove an unspecified item
        shoppingCart3.remove();
        System.out.println("The unspecified item was successfully removed: ");
        System.out.println(shoppingCart3.remove() +"\n");
         
              //check budget
       // System.out.println(shoppingCart3.checkBudget(200)); 
        
       
       shoppingCart3.checkBudget(200);
        //Simulate check out (remove/isEmpty)
        shoppingCart3.checkout();
        
     //check budget
        System.out.println();
    
    }
}
