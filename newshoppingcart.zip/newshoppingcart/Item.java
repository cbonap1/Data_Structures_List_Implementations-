
/* Item.java - bare implementation of an item for sale */
    public class Item
    {
    private String name;
    private int price;  //in cents; 100 = $1.00
    
    public Item(String n, int p)
    {
        name = n;
        price = p;
    }
    
    public int getPrice()
    {
        return price;
    }
    
    public String toString()
    {
        return name + ", $" + price/100 + "." + price % 100;
    }
}